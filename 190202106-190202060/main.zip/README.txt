
### MİNİMUM ÇEVRELEYEN ÇEMBER VE B-SPLINE

```
Kodlayan: Emre Sevindik ve Emir Avcı

```

Spline eğrileri noktalar kümesi çevresinde düzgün bir eğri oluşturmak için kullanılan bir
şerittir. Problemin tanımı Minimum Çevreleyen Çember problemi, aynı zamanda En Küçük
Çember problemi veya Minimum Kapsayan Daire problemi olarak da bilinmektedir.



Projede sizden istenen kullanıcı tarafından tamsayı koordinatlı 2 boyutlu bir düzlemde
N nokta verildiğinde, tüm noktaları içeren minimum çevreleyen yarıçaplı daireyi
çizdirmeniz istenmektedir.
Verilen N noktanın en yakınından geçen eğriyi çizdirmeniz istenmektedir.
Çizdirmiş olduğunuz dairenin ise yarıçapını ve merkezini hesaplamanız istenmektedir



1.2 boyutlu düzlem için gereken N adet noktanın koordinatlarının bir dosya üzerinden
okunması gerekmektedir (.txt veya .csv). Dosyanızda her bir noktanın X ve Y
koordinatları bulunacaktır.

2. Aşağıdaki örnek şekilde verildiği gibi Bu (X,Y) koordinatları temsil eden her bir
noktanın bir arayüz aracılığı ile (koordinat düzleminde) e kranda gösterilmesi
gerekmektedir.

3. Bu noktaların tümünü içine alan e n küçük daireyi ekrana çizdirmeniz
gerekmektedir.

4. Tüm noktaları içeren en küçük dairenin hesapladığınız y arıçapını v e merkezini ç ıktı
olarak göstermeniz ve ekranda dairenin üzerinde göstermeniz gerekmektedir.
5. Verilen tüm noktaların (N tane) en yakınından geçen bir eğrinin ç izdirilmesi
gerekmektedir.

6. Raporunuzda kullanmış olduğunuz yöntemin (b-spline yönteminin) matematik
detaylarına yer veriniz.

7. En son olarak da yazdığınız algoritmanın z aman karmaşıklığı hesabı yapılacaktır.
Yaptığınız tüm hesaplamaları proje raporunuzda göstermeniz gerekmektedir. Zaman
karmaşıklığında direk sonucu yazmayınız. Açıklaması ile birlikte ayrıntılarıyla
anlatınız.

Not: Tüm gösterimleriniz de X ve Y koordinat düzlemini kullanmanız ve noktaları ona göre
göstermeniz beklenmektedir.



Örnek gösterim


Giriş:
{{0, 0}, {0, 1}, {1, 0}}
Çıktı:
Merkez = {0,5, 0,5}
Yarıçap = 0,7071
Açıklama:
Yukarıdaki daire 0.707 yarıçaplı ve merkez (0.5, 0.5) ile çizildiğinde, belirtilen tüm
noktaların dairenin içinde veya üzerinde olduğu görülmektedir.




Proje içinde bulunan noktalar.txt dosyasına gösterilen formatta noktaları girmeniz
istenmektedir. Daha sonra yapmanız gereken tek şey programı çalıştırmaktır. Programı
çalıştırdığınız zaman istenilen merkez, yarıçap ve noktalar ekrana yazdırılacaktır. Ayrıca
çember, noktalar ve eğri çalıştır tuşuna basıldığında kendiliğinden çizdirilecektir. Bunun için
herhangi bir işlem yapmanıza gerek yoktur. Sadece çalıştır tuşuna basmanız yeterli.
